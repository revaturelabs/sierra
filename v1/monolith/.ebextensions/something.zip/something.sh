#!/bin/bash
echo "Private World!" >> Hello.txt
mkdir current_folder